module.exports = { lintOnSave: false }
