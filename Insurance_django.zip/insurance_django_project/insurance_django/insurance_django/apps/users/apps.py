from django.apps import AppConfig


class UsersConfig(AppConfig):
    name = 'insurance_django.apps.users'
