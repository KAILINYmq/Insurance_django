from django.apps import AppConfig


class DataFormConfig(AppConfig):
    name = 'data_form'
